﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l_game
{
    public class Movement
    {
        public long roundcount = 0;
        public Logic logic;

        public Movement(Logic logic)
        {
            this.logic = logic;
        }

        public void Red_Move()
        {
            for(int x = 0; x < 4; x++) 
            {
                for(int y = 0; y < 4; y++)
                {
                    if(logic.boardPiece[x,y] == BoardPiece.Red_L)
                    {
                        logic.boardPiece[x, y] = BoardPiece.Red_Hover;
                    }
                }
            }
        }

        public void Blue_Move()
        {
            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    if (logic.boardPiece[x, y] == BoardPiece.Blue_L)
                    {
                        logic.boardPiece[x, y] = BoardPiece.Blue_Hover;
                    }
                }
            }
        }

        public void Coin_Move()
        {

        }
    }
}
