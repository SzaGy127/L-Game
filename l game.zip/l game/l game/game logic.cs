﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l_game
{
    public class Logic
    {
        public Movement movement;
        public BoardPiece[,] boardPiece = new BoardPiece[4, 4];
        public int HCount = 0;
        public int[,] check = new int[4, 4];
        public bool progress = false;
        public bool legal = false;
        public bool c_Size = false;
        public bool c_Shape = false;
        public bool collides = false;
        public bool did_move = false;
        public int size = 0;
        public int ColCount = 0;

        public Logic()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    check = new int[i, j];
                }
            }
        }

        public void adatmegadas()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    boardPiece[i, j] = BoardPiece.Empty;
                }
            }
            boardPiece[0, 0] = BoardPiece.Coin;
            boardPiece[3, 3] = BoardPiece.Coin;
            boardPiece[1, 0] = BoardPiece.Red_L;
            for (int i = 0; i < 3; i++)
            {
                boardPiece[2, i] = BoardPiece.Red_L;
            }
            boardPiece[2, 3] = BoardPiece.Blue_L;
            for (int i = 1; i < 4; i++)
            {
                boardPiece[1, i] = BoardPiece.Blue_L;
            }
        }

        public void Legality() //uses the other parts to check for legality
        {
            
        }

        public void L_Size() //checks for how many clicked squares there are, if 4, c_Size == true
        {
            for(int i = 0; i < 4; i++)
            {
                for(int j = 0; j < 4; j++)
                {
                    if(movement.roundcount % 4 == 0)
                    {
                        if (boardPiece[i, j] == BoardPiece.Red_L)
                        {
                            size++;
                        }
                    }
                    else if(movement.roundcount % 4 == 2)
                    {
                        if(boardPiece[i,j] == BoardPiece.Blue_L)
                        {
                            size++;
                        }
                    }
                }
            }
            if(size == 4)
            {
                c_Size = true;
            }
        }

        public void L_Shape() //checks for shape, if L, c_Shape == true
        {

        }

        public void Collision() //checks for overlapping squares, if none overlap, collision == false
        {
            for(int x = 0; x < 4; x++)
            {
                for(int y = 0; y < 4; y++)
                {
                    if(movement.roundcount % 4 == 0)
                    {
                        if(boardPiece[x,y] == BoardPiece.Blue_L || boardPiece[x,y] == BoardPiece.Coin)
                        {
                            check[x, y] = 1;
                        }
                        if (boardPiece[x, y] == BoardPiece.Blue_L && check[x, y] == 1)
                        {
                            ColCount++;
                        }
                    }
                    else if(movement.roundcount % 4 == 2)
                    {
                        if(boardPiece[x,y] == BoardPiece.Red_L || boardPiece[x,y] == BoardPiece.Coin)
                        {
                            check[x, y] = 1;
                        }
                        if(boardPiece[x,y] == BoardPiece.Blue_L && check[x,y] == 1)
                        {
                            ColCount++;
                        }
                    }
                }
            }
            if (ColCount == 0)
            {
                collides = false;
            }
            else
            {
                collides = true;
            }
        }

        public void Moved() //checks if the "drawn" L and previous L are matching
        {
            if(movement.roundcount % 4 == 0)
            {
                for (int x = 0; x < 4; x++)
                {
                    for (int y = 0; y < 4; y++)
                    {
                        if(boardPiece[x,y] == BoardPiece.Red_Hover)
                        {
                            HCount++;
                        }
                    }
                }
            }
            else if (movement.roundcount % 4 == 2)
            {
                for (int x = 0; x < 4; x++)
                {
                    for (int y = 0; y < 4; y++)
                    {
                        if (boardPiece[x, y] == BoardPiece.Blue_Hover)
                        {
                            HCount++;
                        }
                    }
                }
            }
            if(HCount != 0)
            {
                did_move = true;
            }
            else
            {
                did_move = false;
            }
        }
    }
}
