﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l_game
{
    public enum BoardPiece
    {
        Coin, Empty, Red_L, Blue_L, Red_Hover, Blue_Hover
    }
}
