﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace l_game
{
    public partial class Form1 : Form
    {
        public Logic game_logic = new Logic();
        public Movement movement;
        public PictureBox[] kepek;
        public PictureBox[,] tabla;

        public Form1()
        {
            movement = new Movement(game_logic);
            InitializeComponent();
            game_logic.adatmegadas();
            kepolvaso();
            kirajzolas();
        }
        
        private void kepolvaso()
        {
            kepek = new PictureBox[6];
            for (int i = 0; i < 6; i++)
            {
                kepek[i] = new PictureBox();
            }
            Bitmap empty = new Bitmap("empty_tiles.png");
            Bitmap red_l = new Bitmap("Red_L.png");
            Bitmap blue_l = new Bitmap("Blue_L.png");
            Bitmap red_hover = new Bitmap("Red_Hover.png");
            Bitmap blue_hover = new Bitmap("Blue_Hover.png");
            Bitmap coin = new Bitmap("coin.png");
            kepek[0].Image = (Image)empty;
            kepek[1].Image = (Image)red_l;
            kepek[2].Image = (Image)red_hover;
            kepek[3].Image = (Image)blue_l;
            kepek[4].Image = (Image)blue_hover;
            kepek[5].Image = (Image)coin;
        }

        private void kirajzolas()
        {
            tabla = new PictureBox[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    tabla[i, j] = new PictureBox();
                    tabla[i, j].Height = 50;
                    tabla[i, j].Width = 50;
                    tabla[i, j].Left = 100 + i * 50;
                    tabla[i, j].Top = 100 + j * 50;
                    tabla[i, j].SizeMode = PictureBoxSizeMode.StretchImage;
                    if (game_logic.boardPiece[i, j] == BoardPiece.Empty)
                    {
                        tabla[i, j].Image = kepek[0].Image;
                    }
                    if (game_logic.boardPiece[i, j] == BoardPiece.Red_L)
                    {
                        tabla[i, j].Image = kepek[1].Image;
                    }
                    if (game_logic.boardPiece[i, j] == BoardPiece.Blue_L)
                    {
                        tabla[i, j].Image = kepek[3].Image;
                    }
                    if (game_logic.boardPiece[i, j] == BoardPiece.Coin)
                    {
                        tabla[i, j].Image = kepek[5].Image;
                    }
                    this.tabla[i, j].BorderStyle = BorderStyle.FixedSingle;
                    this.Controls.Add(tabla[i, j]);
                    tabla[i,j].Click += PictureClick;
                }
            }
        }

        public void PictureClick(object sender, EventArgs e)
        {
            
        }
    }
}
